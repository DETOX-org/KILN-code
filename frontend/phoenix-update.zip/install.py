#!/usr/bin/env python3
"""Install the reviewed phoenix files into a local KILN-code checkout."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile

package = Path(__file__).resolve().parent
root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
manifest = json.loads((package / 'manifest.json').read_text())
if not (root / 'frontend/app/components/DashboardView.jsx').is_file():
    sys.exit('Run this from your KILN-code repository, or pass its path as the first argument.')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None

pending = []
for entry in manifest:
    source, target = package / entry['path'], root / entry['path']
    if digest(source) != entry['after']:
        sys.exit('Package verification failed: ' + entry['path'])
    if target.resolve() != target:
        sys.exit('Refusing to replace a symlink target: ' + entry['path'])
    current = digest(target)
    if current == entry['after']:
        continue
    if target.exists() and not target.is_file():
        sys.exit('Expected a file: ' + entry['path'])
    if current != entry['before']:
        sys.exit('Stopped before making changes: ' + entry['path'] + ' has different contents. Share this message so the update can be merged with your version.')
    pending.append(entry)

if not pending:
    print('Phoenix update is already installed. Open http://localhost:3001.')
    sys.exit(0)
backup = Path(tempfile.mkdtemp(prefix='kiln-phoenix-backup-', dir=root.parent))
for entry in pending:
    target = root / entry['path']
    if target.exists():
        saved = backup / entry['path']
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, saved)
for entry in pending:
    target = root / entry['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(package / entry['path'], target)
print('Phoenix update installed. Refresh http://localhost:3001.')
print('Original files backed up at:', backup)
print('Review your changes with: git diff -- frontend/app/components/DashboardView.jsx')
