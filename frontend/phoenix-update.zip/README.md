# KILN phoenix dashboard update

Adds a navy-and-gold phoenix hero above the existing daily challenge, using the supplied 8-second video. Includes orbit and ember animation, a motion pause button, scroll-revealed community cards, and callbacks to the existing challenge and contest views. No new dependencies. This is an original interpretation of the requested community storytelling style, not a replica of Observal's animation implementation.

## Apply in Ubuntu WSL

Keep the development server running. Open a second Ubuntu terminal:

```bash
cd ~/projects/KILN-code
explorer.exe .
```

Copy the downloaded `phoenix-update.zip` into the folder that opens. Then run:

```bash
git switch -c feat/phoenix-hero
python3 -m zipfile -e phoenix-update.zip /tmp/kiln-phoenix-update
python3 /tmp/kiln-phoenix-update/install.py .
```

If the branch already exists, use `git switch feat/phoenix-hero` instead. The installer checks every file before changing anything and stops on conflicting changes. It creates a backup of replaced files beside your repository. Refresh http://localhost:3001 after installation. If the server is stopped, run `cd frontend` then `npm run dev -- --port 3001`.

The package changes DashboardView.jsx and adds PhoenixHero.jsx, its scoped CSS module, and two media assets under frontend/public/phoenix. Do not commit this ZIP. Stage only the relevant files when preparing your PR.

## Motion and accessibility

- Static phoenix poster is visible before playback, on video failure, and when reduced motion is enabled.
- Decorative media is silent; the poster supplies descriptive alt text.
- Playback pauses offscreen, in a hidden tab, or through the keyboard-accessible pause button.
- Autoplay failure offers an explicit play control.
- Gold buttons call existing dashboard navigation handlers.
- Small screens stack the hero and community cards vertically.
- Other dashboard panels and the older HTML frontend are not redesigned.

## Verification

- Next.js production build passed.
- Production HTTP checks passed for the homepage, phoenix content, original challenge text, video, and poster.
- Installer checked for successful installation, repeat use, and preservation of conflicting edits.
- Browser visual checks could not run because the browser download failed in the build environment. Check desktop/mobile appearance and button interactions locally before opening a PR.
- Backend services were not started or tested. Existing dashboard statistics are unchanged.

## Undo

The installer prints the backup directory. Copy its DashboardView.jsx back to the matching path in your repository; then remove the two PhoenixHero component files and the frontend/public/phoenix directory if you no longer need them. Do not restore the backup over later edits without reviewing them.
